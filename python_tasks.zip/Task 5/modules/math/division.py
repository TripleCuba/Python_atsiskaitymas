def division(a, b):
  return a / b
