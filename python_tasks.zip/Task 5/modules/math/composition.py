def composition(a, b):
  return a + b
