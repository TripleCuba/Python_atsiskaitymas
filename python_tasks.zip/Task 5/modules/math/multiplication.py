def multiplication(a, b):
  return a * b
