def substraction(a, b):
  return a - b
