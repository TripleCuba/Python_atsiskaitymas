# Importuokite reikiamus modulius, kad veiktų žemiau nurodytos funkcijos

# Kitų failų ir žemiau esančio kodo nekeiskite
a = addition(one, four)
b = divivsion(four, two)
c = substraction(three, two)
d = multiplication(five, two)

print(a)
print(b)
print(c)
print(d)